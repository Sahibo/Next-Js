export default function Circulars()
{
    return (
        <div>
            Circulars
        </div>
    )
}