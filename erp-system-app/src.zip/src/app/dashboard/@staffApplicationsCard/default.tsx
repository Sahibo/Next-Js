export default function StaffApplicationsCard()
{
    return (
        <div>Staff appl</div>
    )
}