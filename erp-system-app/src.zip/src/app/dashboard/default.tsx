export default function Dashboard()
{
    return (
        <div>
            Some
        </div>
    )
}