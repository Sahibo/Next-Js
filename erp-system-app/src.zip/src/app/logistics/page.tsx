export default function Logistics()
{
    return (
        <div>
            Logistics
        </div>
    )
}