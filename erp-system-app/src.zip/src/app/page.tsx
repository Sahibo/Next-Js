import Image from "next/image";
import InfoCardM from "../components/InfoCardM";

export default function Home() {
  return (
    <main>
      <InfoCardM />
    </main>
  );
}
