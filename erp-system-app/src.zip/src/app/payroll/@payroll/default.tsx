export default function Payroll()
{
    return (
        <div>
            Payroll
        </div>
    )
}