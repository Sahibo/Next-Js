export default function Payslip()
{
    return (
        <div>
            Payslip
        </div>
    )
}