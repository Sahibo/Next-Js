"use client";
import styles from "../components/styles/cardM.module.css";
import "../app/globals.css";
import { H2, TextMedium, TextSmall } from "./unknown/CustomTexts";
import Table from "./Table";
import MemoSlot from "@/app/dashboard/@memos/default";

export default function InfoCardM() {
  return (
    <div className={`${styles.mainContainer} rectangleContainer`}>
      <H2>Memo</H2>

      <div className={styles.bottomContainer}>
        <MemoSlot />
      </div>
    </div>
  );
}
