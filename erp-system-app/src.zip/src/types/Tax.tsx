export interface Tax
{
    id: number
    taxType: string
    value: number
}

